from .base import WidgetBase


class PluginBase(WidgetBase):

  def __init__(self):
    super(PluginBase, self).__init__()