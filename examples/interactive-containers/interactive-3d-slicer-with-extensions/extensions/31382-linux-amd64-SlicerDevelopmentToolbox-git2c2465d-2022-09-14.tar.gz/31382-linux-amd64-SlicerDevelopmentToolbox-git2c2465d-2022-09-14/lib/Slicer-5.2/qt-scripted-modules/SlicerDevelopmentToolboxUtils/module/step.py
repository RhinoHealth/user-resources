from .base import WidgetBase


class StepBase(WidgetBase):

  def __init__(self):
    super(StepBase, self).__init__()
